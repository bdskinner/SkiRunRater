﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace SkiRunRater
{
    public class Controller
    {
        #region FIELDS

        bool active = true;

        #endregion

        #region PROPERTIES


        #endregion

        #region CONSTRUCTORS

        public Controller()
        {
            ApplicationControl();
        }

        #endregion

        #region METHODS

        private void ApplicationControl()
        {
            //Variable Declarations.
            SkiRunRepository skiRunRepository = new SkiRunRepository();
            List<SkiRun> skiRunDetail = new List<SkiRun>();

            ConsoleView.DisplayWelcomeScreen();

            using (skiRunRepository)
            {
                List<SkiRun> skiRuns = skiRunRepository.GetSkiAllRuns();

                while (active)
                {
                    AppEnum.ManagerAction userActionChoice;
                    SkiRun aSkiRun = new SkiRun();

                    userActionChoice = ConsoleView.GetUserActionChoice();

                    switch (userActionChoice)
                    {
                        case AppEnum.ManagerAction.None:
                            break;
                        case AppEnum.ManagerAction.ListAllSkiRuns:
                            //Display all ski runs.
                            ConsoleView.DisplayAllSkiRuns(skiRuns, true);
                            ConsoleView.DisplayContinuePrompt();
                            break;
                        case AppEnum.ManagerAction.DisplaySkiRunDetail:
                            DisplaySkiRunDetail(skiRunRepository);
                            break;
                        case AppEnum.ManagerAction.DeleteSkiRun:
                            DeleteSkiRun(skiRunRepository, skiRuns);
                            break;
                        case AppEnum.ManagerAction.AddSkiRun:
                            AddSkiRun(skiRunRepository);
                            break;
                        case AppEnum.ManagerAction.UpdateSkiRun:
                            UpdateSkiRun(skiRunRepository, skiRuns);
                            break;
                        case AppEnum.ManagerAction.QuerySkiRunsByVertical:
                            QuerySkiRunsByVertical(skiRunRepository);
                            break;
                        case AppEnum.ManagerAction.Quit:
                            active = false;
                            break;
                        default:
                            break;
                    }
                }
            }

            ConsoleView.DisplayExitPrompt();
        }

        /// <summary>
        /// Adds a record to the data source with information provided by the user.
        /// </summary>
        /// <param name="skiRunRepository"></param>
        private static void AddSkiRun(SkiRunRepository skiRunRepository)
        {
            //Variable Declarations.
            SkiRun aSkiRun = new SkiRun();

            //Get the ski run ID from the user.
            ConsoleView.DisplayHeader("Add a Ski Run");

            //Get the ID, Name, and Vertical feet from the user.
            aSkiRun.ID = ConsoleView.GetIntegerFromUser("Enter the ID for the Ski Run: ");
            aSkiRun.Name = ConsoleView.GetUserResponse("Enter the name for the Ski Run: ");
            aSkiRun.Vertical = ConsoleView.GetIntegerFromUser("Enter the vertical (in feet) for the Ski Run: ");

            //Insert the new ski run.
            try
            {
                //Insert the new record.
                skiRunRepository.InsertSkiRun(aSkiRun);

                //Display a message to the user that the record was inserted.
                ConsoleView.DisplayReset();
                ConsoleView.DisplayMessage($"The information for the {aSkiRun.Name} ski run has been saved.");
                ConsoleView.DisplayContinuePrompt();
            }
            catch (Exception ex)
            {
                //Display the error message for the error that occurred.
                CatchIOExceptions(ex);
            }
        }

        /// <summary>
        /// Handles errors for File I/O operations.
        /// </summary>
        /// <param name="exc"></param>
        private static void CatchIOExceptions(Exception exc)
        {
            if (exc is DriveNotFoundException)
            {
                //Display the error message on the screen.
                ConsoleView.DisplayErrorMessage(exc.Message.ToString());
                Console.ReadKey();
                return;
            }
            else if (exc is DirectoryNotFoundException)
            {
                //Display the error message on the screen.
                ConsoleView.DisplayErrorMessage(exc.Message.ToString());
                Console.ReadKey();
                return;
            }
            else if (exc is FileNotFoundException)
            {
                //Display the error message on the screen.
                ConsoleView.DisplayErrorMessage(exc.Message.ToString());
                Console.ReadKey();
                return;
            }
            else if (exc is EndOfStreamException)
            {
                //Display the error message on the screen.
                ConsoleView.DisplayErrorMessage(exc.Message.ToString());
                Console.ReadKey();
                return;
            }
            else if (exc is ArgumentException)
            {
                //Display the error message on the screen.
                ConsoleView.DisplayErrorMessage(exc.Message.ToString());
                Console.ReadKey();
                return;
            }
            else if (exc is Exception)
            {
                //Display the error message on the screen.
                ConsoleView.DisplayErrorMessage(exc.Message.ToString());
                Console.ReadKey();
            }
        }

        /// <summary>
        /// Deletes a record from the data source using the ID value entered by the user.
        /// </summary>
        /// <param name="skiRunRepository"></param>
        /// <param name="skiRuns"></param>
        private static void DeleteSkiRun(SkiRunRepository skiRunRepository, List<SkiRun> skiRuns)
        {
            //Variable declarations.
            int skiRunID = 0;

            //Display the header for the operation.
            ConsoleView.DisplayHeader("Delete a Ski Run");

            //Display all ski runs.
            ConsoleView.DisplayAllSkiRuns(skiRuns, false);
            Console.WriteLine();
            Console.WriteLine();

            //Get the ID for the ski run from the user.
            skiRunID = ConsoleView.GetIntegerFromUser("Enter Ski Run ID to delete: ");

            try
            {
                //Delete the ski run entered.
                skiRunRepository.DeleteSkiRun(skiRunID);

                //Display a message to the user that the ski run has been deleted.
                ConsoleView.DisplayReset();
                ConsoleView.DisplayMessage($"Ski Run ID: {skiRunID} had been deleted.");
                ConsoleView.DisplayContinuePrompt();
            }
            catch (Exception ex)
            {
                //Display the error message for the error that occurred.
                CatchIOExceptions(ex);
            }
        }

        /// <summary>
        /// Displays a list of all ski runs.
        /// </summary>
        /// <param name="skiRunRepository"></param>
        private static void DisplaySkiRunDetail(SkiRunRepository skiRunRepository)
        {
            ConsoleView.DisplayHeader("Display Ski Run Information");

            try
            {
                //Display the ski run information on the screen.
                ConsoleView.DisplaySkiRunDetail(skiRunRepository.GetSkiRunByID(ConsoleView.GetIntegerFromUser("Enter the ID for the Ski Run: ")));
                ConsoleView.DisplayContinuePrompt();
            }
            catch (Exception ex)
            {
                ConsoleView.DisplayErrorMessage(ex.Message);
                ConsoleView.DisplayContinuePrompt();
            }
        }

        /// <summary>
        /// Allows the user to select a list of ski runs based on the vertical value.
        /// </summary>
        /// <param name="skiRunRepository"></param>
        private static void QuerySkiRunsByVertical(SkiRunRepository skiRunRepository)
        {
            int[] minMaxValues = ConsoleView.DisplayGetSkiRunQuery();
            List<SkiRun> results = skiRunRepository.QueryByVertical(minMaxValues[0], minMaxValues[1]);
            ConsoleView.DisplayQueryResults(results);
            ConsoleView.DisplayContinuePrompt();
        }

        /// <summary>
        /// Updates a specific ski run's information in the data source with data entered by the user.
        /// </summary>
        /// <param name="skiRunRepository"></param>
        /// <param name="skiRuns"></param>
        private static void UpdateSkiRun(SkiRunRepository skiRunRepository, List<SkiRun> skiRuns)
        {
            //Variable Declarations.
            SkiRun aSkiRun = new SkiRun();

            //Display the header information for the operation.
            ConsoleView.DisplayHeader("Update Ski Run Information");

            //Display all ski runs.
            ConsoleView.DisplayAllSkiRuns(skiRuns, false);
            Console.WriteLine();
            Console.WriteLine();

            //Get the information for the ski run to be updated and display it on the screen.
            try
            {
                //Display the ski run information on the screen.
                //ConsoleView.DisplaySkiRunDetail(skiRunRepository.GetSkiRunByID(ConsoleView.GetIntegerFromUser("Enter the ID for the Ski Run: ")));
                aSkiRun = skiRunRepository.GetSkiRunByID(ConsoleView.GetIntegerFromUser("Enter the ID for the Ski Run: "));
                ConsoleView.DisplaySkiRunDetail(aSkiRun);
            }
            catch (Exception ex)
            {
                //Display the error message for the error that occurred.
                CatchIOExceptions(ex);
                return;
            }

            //Get the new Name and Vertical feet from the user.
            Console.WriteLine();
            Console.WriteLine();
            aSkiRun.Name = ConsoleView.GetUserResponse("Enter the new name for the Ski Run: ");
            aSkiRun.Vertical = ConsoleView.GetIntegerFromUser("Enter the new vertical (in feet) for the Ski Run: ");

            //Update the ski run.
            try
            {
                //Update the ski run information.
                skiRunRepository.UpdateSkiRun(aSkiRun);

                //Display a message to the user that the record was updated.
                ConsoleView.DisplayReset();
                ConsoleView.DisplayMessage($"The information for the {aSkiRun.Name} ski run has been updated.");
                ConsoleView.DisplayContinuePrompt();
            }
            catch (Exception ex)
            {
                //Display the error message for the error that occurred.
                CatchIOExceptions(ex);
                return;
            }
        }

        #endregion

    }
}
