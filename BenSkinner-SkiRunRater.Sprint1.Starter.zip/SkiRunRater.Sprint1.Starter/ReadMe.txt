Title: Ski Run Rater
Description: This application will allow the user to view a list of ski runs, add a new 
	ski run, delete a ski run, modify a ski run's record, and search for a ski run
	by the vertical feet of the ski run.
Application Type: Console
Author: Ben Skinner, Ryan Parlin
Date Created: 10/31/2017
Last Modified: 11/3/2017